# Taking the project to the next level on **https://github.com/SkyCascade/SkyLearn** 🚀

# Repository Moved to [SkyCascade/SkyLearn](https://github.com/SkyCascade/SkyLearn) and no longer maintained here

### Please update your bookmarks and direct all issues and pull requests to the new repository.

---

*Note: This repository is archived and read-only.*

---

### Learning management system using django web framework

Feature-rich learning management system. You may want to build a learning management system(AKA school management system) for a school organization or just for the sake of learning the tech stack and building your portfolio, either way, this project would be a good kickstart for you.

![Screenshot from 2023-12-31 17-36-31](https://github.com/adilmohak/django-lms/assets/60693922/e7fb628a-6275-4160-ae0f-ab27099ab3ca)
